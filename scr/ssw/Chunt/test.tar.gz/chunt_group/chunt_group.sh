#!/bin/bash

#Chunk_group
#Регистрация
#./sipp -sf test/chunt_group/uac_reg.xml 192.168.23.210:5065 -i 192.168.18.26 -m 1 -s 900 -ap 123 -p 5090
./sipp -sf test/chunt_group/uac_reg.xml 192.168.23.210:5065 -i 192.168.18.26 -m 1 -s 910 -ap 123 -p 5091
./sipp -sf test/chunt_group/uac_reg.xml 192.168.23.210:5065 -i 192.168.18.26 -m 1 -s 911 -ap 123 -p 5092
./sipp -sf test/chunt_group/uac_reg.xml 192.168.23.210:5065 -i 192.168.18.26 -m 1 -s 912 -ap 123 -p 5093
#Запускаем UAS

gnome-terminal -e 'bash -c "cd ~/sipp/sipp-3.4.1; ./sipp -sf test/chunt_group/uas_bye.xml 192.168.23.210:5065 -i 192.168.18.26 -m 1 -p 5091; exec bash"'&
gnome-terminal -e 'bash -c "cd ~/sipp/sipp-3.4.1; ./sipp -sf test/chunt_group/uas_bye.xml 192.168.23.210:5065 -i 192.168.18.26 -m 2 -p 5092 ; exec bash"'&
gnome-terminal -e 'bash -c "cd ~/sipp/sipp-3.4.1; ./sipp -sf test/chunt_group/uas_bye.xml 192.168.23.210:5065 -i 192.168.18.26 -m 3 -p 5093 ; exec bash"'&

#Запускаем UAC

./sipp -sf test/chunt_group/uac.xml -inf test/chunt_group/calls.csv 192.168.23.210:5065 -i 192.168.18.26 -m 4 -t un  -max_socket 20 -r 1
